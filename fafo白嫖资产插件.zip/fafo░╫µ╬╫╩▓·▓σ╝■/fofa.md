# 1.  脚本功能：

## 1.  脚本简介：

### 通过此脚本，你可以在使用  fofa 搜索引擎的时候，根据 fofa  的语法，进行快速地过滤，以一种合法的方法，节省了你手动去输入过滤语法的时间，从而增加了你的效率

## 2.  脚本工作原理简介：

### 1.  首先我们定义一个 setTimeout() 箭头定时器函数，设置其启动时间，我们根据通过 js 获取到 fofa 当前页面下全部的 标题盒子 以及具有相同的 host 主机盒子，并且返回两个数组（titleNodes ，hostNodes，长度都是 10），然后我们使用 for 循环去判断，循环 10 次，每次循环如果发现 title 为空的话，则过滤主机；如果发现 title 不为空，就过滤 host 的 ip 地址，这样一来你就可以获得大量 fofa 资源了

### 2.  其它的一些是属于前端的东西，动画效果是 css ，如有前端基础，可以对其进行相应的修改。

# 2.  javascript 脚本源码：

```javascript
// ==UserScript==
// @name         无需会员白嫖 fofa 所有资产
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  fofa 快速过滤 js 脚本
// @author       凌度
// @match        https://fofa.info/result*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=fofa.info
// @grant        none
// @license      MIT
// ==/UserScript==

setTimeout(() => {
  const div = document.querySelector("div.el-autocomplete")
  div.insertAdjacentElement("afterend", button)
  button.addEventListener("click", () => {
    let qbase64 = A2B(new URL(location.href).searchParams.get("qbase64"))
    const titleNodes = document.querySelectorAll("p.hsxa-two-line") //doms having title information
    const hostNodes = document.querySelectorAll("span.hsxa-host > a") //doms having host information
    const length = titleNodes.length
    const existMap = new Set() //judge if the title exist already
    for (let i = 0; i < length; i++) {
      const title = titleNodes[i].textContent.trim()
      if (title == "") { //title if empty, use host to filter
        const host = hostNodes[i].textContent.trim()
        qbase64 += `&&host!="${host}"`
      } else if (!existMap.has(title)) { //title is fresh, filter it
        qbase64 += `&&title!="${title}"`
        existMap.add(title)
      }
    }
    qbase64 = B2A(qbase64)
    const url = new URL(location.href)
    url.searchParams.set("qbase64", qbase64)
    location.replace(url.href)
  })
}, 1000)

const style = document.createElement("style")
style.innerHTML = `
.conix-button {
  position: absolute;
  margin-left: 20px;
  height: 50px;
  padding: 0 10px;
  white-space: nowrap;
  font-size: xx-large;
  background-color: transparent;
  border: none;
  transition: transform .5s;
}
.conix-button:hover {
  cursor: pointer;
  transform: rotate(135deg);
}
`
document.head.appendChild(style)

const button = document.createElement("button")
button.className = "conix-button"
button.textContent = "🗡️"
button.title = "Kill What You Have Tested Intelligently"

/**
 * Binary To Ascii (Palin To Base64) supporting Chinese
 * @param {string} str
 * @returns
 */
function B2A(str) {
  return window.btoa(unescape(encodeURIComponent(str)))
}

/**
 * Ascii To Binary (Base64 To Plain) supporting Chinese
 * @param {string} str
 * @returns
 */
function A2B(str) {
  return decodeURIComponent(escape(window.atob(str)));
}
```

# 3.  使用方法：

## 1.  导入到油猴脚本里面，然后打开 fofa 页面，会出现一把剑，之后你即可通过点击该图标从而快速地过滤，在无会员的条件下获取大量资产